const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'mydefaultsecretkey';

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Database connection
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '12345678',
  database: 'db_03',
  waitForConnections: true,
  connectionLimit: 100,
  queueLimit: 0
});



// Registration endpoint


app.post('/api/register', async (req, res) => {
  try {
    const { account_type, first_name, last_name, email, phone, university, company, password } = req.body;
    
    // Validate input
    if (!first_name || !last_name || !email || !phone || !password) {
      return res.status(400).json({ error: 'Required fields are missing' });
    }

    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters' });
    }

    // Additional validation based on account type
    if (account_type === 'participant' && !university) {
      return res.status(400).json({ error: 'University is required for participants' });
    }

    if (account_type === 'sponsor' && !company) {
      return res.status(400).json({ error: 'Company name is required for sponsors' });
    }

    // Hash password
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Save to database
    const [result] = await pool.execute(
      `INSERT INTO User 
       (Name, Email, Type, Phone, University, Company, Password_Hash) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        `${first_name} ${last_name}`,
        email,
        account_type,
        phone,
        university || null,
        company || null,
        hashedPassword
      ]
    );

    res.status(201).json({ 
      success: true,
      message: 'Registration successful',
      user: {
        id: result.insertId,
        name: `${first_name} ${last_name}`,
        email,
        type: account_type
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ 
        success: false,
        error: 'Email already registered' 
      });
    }
    res.status(500).json({ 
      success: false,
      error: 'Internal server error' 
    });
  }
});





// Login endpoint


app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    // Find user by email
    const [users] = await pool.execute(
      'SELECT * FROM User WHERE Email = ?',
      [email]
    );

    // Check if user exists
    if (users.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = users[0];

    // Compare passwords
    const passwordMatch = await bcrypt.compare(password, user.Password_Hash);
    
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Create token
    const token = jwt.sign(
      { userId: user.User_ID, email: user.Email, type: user.Type },
      JWT_SECRET,
      { expiresIn: '1h' }
    );
    

    // Successful login response
    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user.User_ID,
        name: user.Name,
        email: user.Email,
        type: user.Type
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get participants endpoint

app.get('/api/participants', async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT Name as name, University as university FROM User WHERE Type = 'participant'"
    );
    res.json({ success: true, participants: rows });
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).json({ success: false, error: 'Database error' });
  }
});


// Venues

app.get('/api/venue', async (req, res) => {
  try {
    const [venues] = await pool.execute(
      `SELECT 
        Venue_ID,
        Name,
        Location,
        Capacity
      FROM venue`
    );

    res.json({
      success: true,
      venues
    });
  } catch (error) {
    console.error('Error fetching venues:', error);
    res.status(500).json({ 
      success: false,
      error: 'Internal server error' 
    });
  }
});

// Create Event endpoint (manual Event_ID increment)
app.post('/api/events', async (req, res) => {
    try {
        const {
            name,
            description,
            rules,
            reg_fee,
            max_participants,
            date_time
        } = req.body;

        // Basic validation
        if (!name || !reg_fee || !max_participants || !date_time) {
            return res.status(400).json({ success: false, error: 'Name, reg_fee, max_participants, and date_time are required' });
        }

        // Get the current maximum Event_ID
        const [rows] = await pool.query('SELECT MAX(Event_ID) AS maxId FROM Event');
        const maxId = rows[0].maxId || 0;
        const nextEventId = maxId + 1;

        // Insert with manually generated Event_ID
        await pool.execute(
            `INSERT INTO Event (Event_ID, Name, Description, Rules, Reg_Fee, Max_Participants, Date_Time)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                nextEventId,
                name,
                description || null,
                rules || null,
                reg_fee,
                max_participants,
                date_time
            ]
        );

        res.status(201).json({
            success: true,
            message: 'Event created',
            event: {
                id: nextEventId,
                name
            }
        });

    } catch (error) {
        console.error('Error creating event:', error);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// API to get events
app.get('/api/eventss', async (req, res) => {
    try {
        const [events] = await pool.execute(
            'SELECT Event_ID, Name, Description, Date_Time, Rules, Reg_Fee, Max_Participants FROM event'
        );
        res.json(events);
    } catch (error) {
        console.error('Error fetching events:', error);
        res.status(500).json({ error: 'Database error' });
    }
});

// Add this endpoint to your index.js file
app.get('/api/dashboard-stats', async (req, res) => {
  try {
    // Get total events count
    const [eventsCount] = await pool.query('SELECT COUNT(*) as count FROM Event');
    
    // Get total participants count
    const [participantsCount] = await pool.query(
      "SELECT COUNT(*) as count FROM User WHERE Type = 'participant'"
    );
    
    // Get total venues count
    const [venuesCount] = await pool.query('SELECT COUNT(*) as count FROM Venue');
    
    // Get total sponsors count
    const [sponsorsCount] = await pool.query(
      "SELECT COUNT(*) as count FROM User WHERE Type = 'sponsor'"
    );

    res.json({
      success: true,
      stats: {
        totalEvents: eventsCount[0].count,
        totalParticipants: participantsCount[0].count,
        totalVenues: venuesCount[0].count,
        totalSponsors: sponsorsCount[0].count
      }
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({ 
      success: false,
      error: 'Internal server error' 
    });
  }
});


const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});