const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const app = express();
const port = 3000;

// Middleware
app.use(express.json());
app.use(express.static(__dirname));

// Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'nascon_db'
});

// Connect to database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to database');
});

// Register endpoint
app.post('/api/register', (req, res) => {
    const { username, email, password } = req.body;
    const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
    
    db.query(query, [username, email, password], (err, result) => {
        if (err) {
            console.error('Error registering user:', err);
            return res.status(500).json({
                success: false,
                error: 'Error registering user'
            });
        }
        res.json({
            success: true,
            message: 'User registered successfully'
        });
    });
});

// Login endpoint
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const query = 'SELECT * FROM users WHERE email = ? AND password = ?';
    
    db.query(query, [email, password], (err, results) => {
        if (err) {
            console.error('Error logging in:', err);
            return res.status(500).json({
                success: false,
                error: 'Error during login'
            });
        }
        
        if (results.length === 0) {
            return res.status(401).json({
                success: false,
                error: 'Invalid credentials'
            });
        }

        res.json({
            success: true,
            user: results[0]
        });
    });
});

// Participant registration endpoint
app.post('/api/participant', (req, res) => {
    const { name, email, event_id, team_name } = req.body;
    const query = 'INSERT INTO participants (name, email, event_id, team_name) VALUES (?, ?, ?, ?)';
    
    db.query(query, [name, email, event_id, team_name], (err, result) => {
        if (err) {
            console.error('Error registering participant:', err);
            return res.status(500).json({
                success: false,
                error: 'Error registering participant'
            });
        }
        res.json({
            success: true,
            message: 'Participant registered successfully'
        });
    });
});

// Get participants endpoint
app.get('/api/participants', (req, res) => {
    const query = 'SELECT * FROM participants';
    
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching participants:', err);
            return res.status(500).json({
                success: false,
                error: 'Error fetching participants'
            });
        }
        res.json({
            success: true,
            participants: results
        });
    });
});

// Venues API endpoint
app.get('/api/venue', (req, res) => {
    const query = 'SELECT * FROM venues';
    
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching venues:', err);
            return res.status(500).json({
                success: false,
                error: 'Error fetching venues from database'
            });
        }

        res.json({
            success: true,
            venues: results
        });
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
}); 